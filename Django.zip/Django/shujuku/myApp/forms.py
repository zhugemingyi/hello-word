from django import forms
from captcha.fields import CaptchaField
from .models import Books


class UserForm(forms.Form):
    username = forms.CharField(label="用户名", max_length=128, widget=forms.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(label="密码", max_length=256, widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    # captcha = CaptchaField(label='验证码')


class BorrowForm(forms.Form):
    JDATE = forms.DateField(label="借书日期", widget=forms.DateInput(attrs={'class': 'form-control'}))
    BNO = forms.CharField(label="书号", widget=forms.TextInput(attrs={'class': 'form-control'}))
    # captcha = CaptchaField(label='验证码')


class BookForm(forms.Form):
    BNA = forms.CharField(label="书名", widget=forms.TextInput(attrs={'class': 'form-control'}))
