from django.db import models


# Create your models here.

class Students(models.Model):
    SNO = models.CharField(primary_key=True, max_length=20)
    SNA = models.CharField(max_length=20)
    SDE = models.CharField(max_length=20, blank=True)
    SSP = models.CharField(max_length=20, blank=True)
    SUP = models.IntegerField()

    def __str__(self):
        return self.SNO


class Books(models.Model):
    BNO = models.CharField(primary_key=True, max_length=20)
    BNA = models.CharField(max_length=30)
    BDA = models.DateField(null=True, blank=True)
    BPU = models.CharField(max_length=30, blank=True)
    BPL = models.CharField(max_length=20, blank=True)
    BNU = models.FloatField(null=True, blank=True)

    def __str__(self):
        return self.BNO


class Borrow(models.Model):
    JDATE = models.DateField()
    HDATE = models.DateField(null=True, blank=True)
    SNO = models.ForeignKey(Students, to_field='SNO', on_delete=models.CASCADE)
    BNO = models.ForeignKey(Books, to_field='BNO', on_delete=models.CASCADE)
    fajin = models.IntegerField(null=True, blank=True)


class User(models.Model):
    SNO = models.ForeignKey(Students, to_field='SNO', on_delete=models.CASCADE)
    MIMA = models.CharField(max_length=4)

    '''class Meta:
        verbose_name = '用户'
        verbose_name_plural = '用户'''''

