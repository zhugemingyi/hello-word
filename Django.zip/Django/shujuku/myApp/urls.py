from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    url(r'^index/', views.index),
    # url('logout/', auth_views.LogoutView.as_view(), name='logout'),
    # url('', views.dashboard, name='dashboard'),
    url(r'^book_bno', views.book_bno),
    # url(r'^', views.login),
    url(r'^book/', views.book),
    url(r'^login/', views.login),
    url(r'^logout/', views.logout),
    url(r'^borrow/', views.borrow)
]
