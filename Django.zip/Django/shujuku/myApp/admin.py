from django.contrib import admin

# Register your models here.
from .models import Books, Students, Borrow, User


@admin.register(Books)
class BooksAdmin(admin.ModelAdmin):
    list_display = ['BNO', 'BNA', 'BDA', 'BPU', 'BPL', 'BNU']  # 显示字段
    # list_filter = []    #过滤字段
    search_fields = ['BNO']    # 搜索字段
    # list_per_page =     #列表页

    fields = ['BNO', 'BNA', 'BDA', 'BPU', 'BPL', 'BNU']
    # fieldsets = []


@admin.register(Students)
class StudentsAdmin(admin.ModelAdmin):
    list_display = ['SNO', 'SNA', 'SDE', 'SSP', 'SUP']

    fields = ['SNO', 'SNA', 'SDE', 'SSP', 'SUP']
    search_fields = ['SNO']


@admin.register(Borrow)
class BorrowAdmin(admin.ModelAdmin):
    """def gender(self):
        pass
    gender.short_description = '罚金"""
    list_display = ['JDATE', 'HDATE', 'SNO', 'BNO', 'fajin']

    fieldsets = [
        ('借书', {'fields': ['JDATE', 'SNO', 'BNO']}),
        ('还书', {'fields': ['HDATE']}),
        # ('交罚金', {'fields': ['fajin']}),
    ]
    list_filter = ['SNO']


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ['SNO', 'MIMA']
    fields = ['SNO', 'MIMA']


'''class BorrowAdmin2(admin.ModelAdmin):
    def gender(self):
        pass
    gender.short_description = '罚金'
    list_display = ['JDATE', 'HDATE', 'SNO', 'BNO', gender]

    fieldsets = [
        # ('借书', {'fields': ['JDATE', 'SNO', 'BNO']}),
        ('还书', {'fields': ['HDATE']}),
    ]'''
# admin.site.register(Books, BooksAdmin)
# admin.site.register(Students, StudentsAdmin)
# admin.site.register(Borrow, BorrowAdmin)
