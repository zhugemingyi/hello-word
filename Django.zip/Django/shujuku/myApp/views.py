from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from .models import Books, Borrow, Students
from .forms import UserForm, BorrowForm, BookForm
from django.http import HttpResponse
from . import models
from django.contrib.auth.decorators import login_required


def index(request):
    return render(request, 'myApp/index.html')


def login(request):
    if request.session.get('is_login', None):
        return redirect('/index/')
    if request.method == "POST":
        login_form = UserForm(request.POST)
        message = "请检查填写的内容！"
        if login_form.is_valid():
            username = login_form.cleaned_data['username']
            password = login_form.cleaned_data['password']
            try:
                user = models.User.objects.get(SNO=username)
                if user.MIMA == password:
                    request.session['is_login'] = True
                    request.session['user_id'] = user.SNO
                    request.session['user_name'] = user.SNO
                    return redirect('/index/')
                else:
                    message = "密码不正确！"
            except:
                message = "用户不存在！"
        return render(request, 'myApp/login.html', locals())

    login_form = UserForm()
    return render(request, 'myApp/login.html', locals())


def logout(request):
    if not request.session.get('is_login', None):
        # 如果本来就未登录，也就没有登出一说
        return redirect("/index/")
    request.session.flush()
    # 或者使用下面的方法
    # del request.session['is_login']
    # del request.session['user_id']
    # del request.session['user_name']
    return redirect("/index/")


def detail(request, num):
    return HttpResponse('detail-%s' % num)


def book(request):
    if not request.session.get('is_login', None):
        return redirect("/index/")
    books_list = Books.objects.all()
    book_form = BookForm(request.POST)
    if book_form.is_valid():
        bna = book_form.cleaned_data['BNA']
        # request.session['user_bna'] = bna
        books_list = Books.objects.filter(BNA=bna)
        return render(request, 'myApp/Book_bno.html', {'books': books_list})
    return render(request, 'myApp/Books.html', {'book_form': book_form, 'books': books_list})


def book_bno(request, num):
    pass


def borrow(request):
    if not request.session.get('is_login', None):
        return redirect("/index/")
    message = request.session['user_id']
    if request.method == "POST":
        register_form = BorrowForm(request.POST)
        message = "请检查填写的内容！"
        if register_form.is_valid():  # 获取数据
            jdate = register_form.cleaned_data['JDATE']
            bno = register_form.cleaned_data['BNO']
            message = 'kkk'
            try:
                new_user = Borrow.objects.create(SNO=request.session['user_id'], JDATE=jdate, BNO=Books.objects.get(BNO=bno))
                message = '借书成功'
            except:
                message = '借书数量已达上限'
                # message = new_user.SNO
            return render(request, 'myApp/borrow.html', {'message': message, 'register_form': register_form})
    register_form = BorrowForm()
    return render(request, 'myApp/borrow.html', locals())


'''def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            student = authenticate(request, username=cd['username'],
                                   password=cd['password'])
            if student is not None:
                if student.is_active:
                    login(request, student)
                    return HttpResponse('Authenticated' 'successfully')
                else:
                    return HttpResponse('Disabled account')
            else:
                return HttpResponse('用户名不存在或密码错误')
    else:
        form = LoginForm()
    return render(request, r'myApp/login.html', {'form': form})'''
